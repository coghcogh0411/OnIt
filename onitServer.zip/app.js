var createError = require('http-errors');
var express = require('express');
const http = require("http");
const axios = require("axios");
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const mongoose = require("mongoose");
var app = express();
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*"); // 모든 출처 허용
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  if (req.method === "OPTIONS") {
    return res.sendStatus(200); // 또는 204
  }
  next();
});

// MongoDB 연결 (연결 문자열을 본인 환경에 맞게 수정)
mongoose.connect('mongodb://localhost:27017/chatDB', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("✅ MongoDB 연결 성공!"))
  .catch(err => console.error("❌ MongoDB 연결 실패:", err));

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

const server = http.createServer(app);

// 채팅 메시지 스키마 정의
const ChatSchema = new mongoose.Schema({
  sender: String,
  receiver: String,
  message: String,
  timestamp: { type: Date, default: Date.now },
});
const ChatRoomSchema = new mongoose.Schema({
  user1: String,
  user2: String,
  lastRead: {
    user1: { type: Date, default: null },
    user2: { type: Date, default: null },
  }
});
const Chat = mongoose.model("Chat", ChatSchema);
const ChatRoom = mongoose.model("ChatRoom", ChatRoomSchema);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

const io = require("socket.io")(server, {
  cors: {
    origin: "*",
  }
});
server.listen(8888, () => {
  console.log('서버가 8888 포트에서 실행 중입니다.');
});

app.get("/test", (req, res) => {
  res.json({ message: "CORS test" });
});

// 채팅 기록 불러오기 
app.get("/chat/history", async (req, res) => {
  const { partner, userId } = req.query;
  console.log("채팅 기록 요청:", { userId, partner });

  const messages = await Chat.find({
    $or: [
      { sender: userId, receiver: partner },
      { sender: partner, receiver: userId }
    ]
  }).sort("timestamp");

  console.log("불러온 채팅 기록:", messages);
  res.json(messages);
});

// 채팅방 목록 불러오기
app.get("/chat/rooms", async (req, res) => {
  console.log("GET /chat/rooms 호출됨");
  const userId = req.query.userId;
  console.log("채팅방 목록 요청 - userId:", userId);
  //mongodb채팅방에 보낸사람이나 받을사람에 자신이있으면 romms=true
  const rooms = await ChatRoom.find({
    $or: [{ user1: userId }, { user2: userId }]
  });
  //자신 id가포함된 채팅방 모두조회
  const partners = rooms.map(room =>
    room.user1 === userId ? room.user2 : room.user1
  );

  console.log("불러온 채팅 상대 목록:", partners);
  const result = [];
  for (const room of rooms) {
    // 상대방 ID
    const partner = room.user1 === userId ? room.user2 : room.user1;

    // lastReadTime: 해당 userId가 마지막으로 읽은 시간
    let lastReadTime = null;
    if (room.user1 === userId) {
      lastReadTime = room.lastRead.user1;
    } else {
      lastReadTime = room.lastRead.user2;
    }

    // null이면 예전 메시지 모두 안 읽은 것으로 간주할 수도 있으니 기본값 설정
    const compareTime = lastReadTime || new Date(0);

    // 안 읽은 메시지 수: partner가 보낸 메시지 중 compareTime 이후의 메시지
    const unreadCount = await Chat.countDocuments({
      sender: partner,
      receiver: userId,
      timestamp: { $gt: compareTime },
    });

    result.push({
      partner,
      unreadCount,
    });
  }

  res.json(result);
});

app.post("/chat/rooms/read", async (req, res) => {
  try {
    const { userId, partner } = req.body;
    console.log("읽음 처리 요청:", userId, partner);

    const room = await ChatRoom.findOne({
      $or: [
        { user1: userId, user2: partner },
        { user1: partner, user2: userId },
      ],
    });
    if (!room) {
      return res.status(404).json({ error: "채팅방이 존재하지 않습니다." });
    }

    // user1이 방을 열었다면 room.lastRead.user1을 갱신
    if (room.user1 === userId) {
      room.lastRead.user1 = new Date();
    } else {
      room.lastRead.user2 = new Date();
    }
    await room.save();

    res.json({ success: true });
  } catch (err) {
    console.error("읽음 처리 에러:", err);
    res.status(500).json({ error: "서버 에러" });
  }
});

io.on("connection", (socket) => {
  console.log("사용자 연결됨");
  //사용자 접속하면 자신의 이름으로 된 방에 접속
  socket.on("joinRoom", (userId) => {
    socket.join(userId);
    console.log(`Socket ${socket.id} joined room: ${userId}`);
  });

  // bid받으면
  socket.on("bid", async (data) => {
    try {
      setTimeout(async () => {
        //오라클db조회해서데이터가져옴
        const response = await axios.get(
          `http://192.168.0.46:8082/bid.get?auctionNo=${data.auctionNo}`,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        let bids = response.data;
        //그 데이터 updateBids로 전체 클라이언트에게 보냄
        io.sockets.emit("updateBids", bids.bid);
      }, 500);
    } catch (err) {
      console.error("❌ 입찰 처리 오류:", err);
    }
  });
  //sendMessage받으면 보낸사람,받을사람, 메시지 시간데이터 클라이언트한테 받음
  socket.on("sendMessage", async (data) => {
    console.log("sendMessage 이벤트 수신:", data);
    const chat = new Chat(data);
    //그 데이터 mongodb 저장
    await chat.save();
    console.log("메시지 저장 완료:", chat);

    // 채팅방 있는지 확인
    const existingRoom = await ChatRoom.findOne({
      $or: [
        { user1: data.sender, user2: data.receiver },
        { user1: data.receiver, user2: data.sender },
      ],
    });
    //없으면 채팅방 생성
    if (!existingRoom) {
      const newRoom = new ChatRoom({ user1: data.sender, user2: data.receiver });
      await newRoom.save();
      console.log("새 채팅방 생성:", newRoom);
    }

    console.log("수신자에게 메시지 전송:", data.receiver);
    //받을사람에게만 데이터를 receiveMessage로 보냄
    io.to(data.receiver).emit("receiveMessage", data);
  });

  socket.on("disconnect", () => {
    console.log("사용자 연결 종료");
  });
});



// catch 404
app.use(function (req, res, next) {
  res.status(404);
  res.render('error', { message: 'Page Not Found', error: {} });
});

// error handler
app.use(function (err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
